<?php $__env->startSection('main-content'); ?>


<nav>
        <div class="right">
          <div class="top">
            <button id="menu-btn">
              <span class="material-icons-sharp">menu</span>
            </button>
            <div class="theme-toggler">
              <span class="material-icons-sharp active">light_mode</span>
              <span class="material-icons-sharp">dark_mode</span>
            </div>
            <div class="profile">
              <div class="info">
                <p>Hey, <b>Daniel</b></p>
                <small class="text-muted">Admin</small>
              </div>
              <div class="profile-photo">
                <img src="assets/images/profile-1.jpg" />
              </div>
            </div>
          </div>
        </div>
      </nav>


      <h1>Data Karyawan</h1>

      <div class="list-data-karyawan">
        <div class="pengajuan-lembur">
          <h3>List Pengajuan Lembur Terbaru</h3>
          <table id="lembur" class="display nowrap" style="width:90%">
            <thead>
              <tr>
                <th>No</th>
                <th>Nama Karyawan</th>
                <th>Departmen</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>1</td>
                <td>Indrianto</td>
                <td>Keuangan</td>
                <td>Menunggu</td>
              </tr>
              <tr>
                <td>2</td>
                <td>Fitra</td>
                <td>Sumber Daya Manusia</td>
                <td>Menunggu</td>
              </tr>
              <tr>
                <td>3</td>
                <td>Devin Nuriansyah</td>
                <td>Managemen</td>
                <td>Menunggu</td>
              </tr>
            </tbody>
          </table>
          <button class="btn btn-success"><a href="/index.html">Lihat Semua</a></button>
        </div>
      </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/stikom_admin/resources/views/admin/data_karyawan.blade.php ENDPATH**/ ?>
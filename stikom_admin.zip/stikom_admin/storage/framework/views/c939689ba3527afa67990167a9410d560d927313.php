<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- Fonts -->
    <!-- MATERIAL CDN -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet" />


    <link href="<?php echo e(asset('asset/style.css')); ?>" rel="stylesheet" />
    <!-- Data Table CSS -->
  <link href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.12.1/datatables.min.css" />

  <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.12.1/datatables.min.js"></script>
</head>

<body>
  <div class="container">

            <?php echo $__env->make('layout.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <main>
          <?php echo $__env->yieldContent('main-content'); ?>
      </main>

  </div>
</body>

          <script src="<?php echo e(asset('index.js')); ?>"></script>
          <script>
    const ctx = document.getElementById('chartKehadiran').getContext('2d');
    const chartKehadiran = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Hadir', 'Tidak Hadir'],
        datasets: [{
          label: '# of Votes',
          data: [50, 19],
          backgroundColor: [
            '#3CC27A',
            '#FF7570'
          ]
        }]
      },
      options: {
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });
  </script>



  <script>
    var dropdown = document.getElementsByClassName("dropdown-btn");
    var i;

    for (i = 0; i < dropdown.length; i++) {
      dropdown[i].addEventListener("click", function () {
        this.classList.toggle("active");
        var dropdownContent = this.nextElementSibling;
        if (dropdownContent.style.display === "block") {
          dropdownContent.style.display = "none";
        } else {
          dropdownContent.style.display = "block";
        }
      });
    }
  </script>

  <script>
    $(document).ready(function () {
      $('#lembur').DataTable({
        scrollX: true,
      });
      $('#izin').DataTable({
        scrollX: true,
      });
    });
  </script>
</html>
<?php /**PATH /var/www/html/stikom_admin/resources/views/layout/app.blade.php ENDPATH**/ ?>